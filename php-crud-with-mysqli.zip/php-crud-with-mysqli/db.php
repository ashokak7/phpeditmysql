<?php
	$conn = mysqli_connect("localhost","root","","blog_samples");
?>